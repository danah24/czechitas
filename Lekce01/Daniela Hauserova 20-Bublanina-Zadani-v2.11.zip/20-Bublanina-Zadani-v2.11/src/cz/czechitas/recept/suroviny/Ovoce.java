package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class Ovoce extends AbstractNadobaSKusovouSurovinou {

    public Ovoce(String jmeno) {
        super(jmeno, 55);
    }
}
